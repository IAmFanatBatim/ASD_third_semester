#include "../VoidSingleList/VoidSingleList.h" // Cмотреть лаб.раб. №5

typedef List Table;
typedef char T_Key[16]; // Определить тип ключа

int main() {
    Table T;
}